﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using Newtonsoft.Json;

namespace ProjectGameLibraryOOP
{
    public partial class MainWindow : Window
    {
        private List<GameInfo> gameList = new List<GameInfo>();

        public MainWindow()
        {
            InitializeComponent();
            LoadGameList();
        }
       


        private void LoadGameList()
        {
            try
            {
                string filePath = "games.json";
                if (File.Exists(filePath))
                {
                    string jsonData = File.ReadAllText(filePath);
                    gameList = JsonConvert.DeserializeObject<List<GameInfo>>(jsonData);
                }
                lstGames.Items.Clear();
                lstGames.ItemsSource = gameList;
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("The game list file could not be found. Please make sure that it exists and try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (IOException ex)
            {
                MessageBox.Show("An error occurred while reading the game list file. Please try again later.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Maak een nieuwe Game object aan en vul de eigenschappen in met gegevens uit de textboxes
                GameInfo newGame = new GameInfo();
                newGame.Title = Gametxt.Text;
                newGame.Genre = Genretxt.Text;
                newGame.Publisher = Publishertxt.Text;
                newGame.Platform = Platformtxt.Text;
                newGame.ReleaseYear = int.Parse(Yeartxt.Text);

                // Voeg de nieuwe game toe aan de gameList
                gameList.Add(newGame);

                // Serializeer de gameList en sla het op als een JSON-bestand
                string json = JsonConvert.SerializeObject(gameList);
                File.WriteAllText("games.json", json);

                // Laad de gameList opnieuw in de ListView
                LoadGameList();
                lblStatus.Content = "Game added successfully!";
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid year.");
            }
        }

        private void btnChange_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Laad alle spellen vanuit het JSON-bestand
                List<GameInfo> games = new List<GameInfo>();
                if (File.Exists("games.json"))
                {
                    string json = File.ReadAllText("games.json");
                    games = JsonConvert.DeserializeObject<List<GameInfo>>(json);
                }

                // Zoek het spel met de overeenkomstige titel, genre, uitgever of platform
                string searchTerm = Gametxt.Text;
                GameInfo searchResult = games.FirstOrDefault(g => g.Title == searchTerm || g.Genre == searchTerm || g.Publisher == searchTerm || g.Platform == searchTerm);

                // Toon de bijkomende details van het gevonden spel in de lijst
                lstGames.Items.Clear();
                if (searchResult != null)
                {
                    lstGames.Items.Add($"Title: {searchResult.Title}");
                    lstGames.Items.Add($"Genre: {searchResult.Genre}");
                    lstGames.Items.Add($"Publisher: {searchResult.Publisher}");
                    lstGames.Items.Add($"Platform: {searchResult.Platform}");
                    lstGames.Items.Add($"Release Year: {searchResult.ReleaseYear}");
                }
                else
                {
                    lstGames.Items.Add("No results found.");
                }
                LoadGameList();
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File not found: " + ex.Message);
            }
            catch (IOException ex)
            {
                MessageBox.Show("Error reading file: " + ex.Message);
            }
        }
    }
}

