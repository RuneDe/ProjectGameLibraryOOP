﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using Newtonsoft.Json;

namespace ProjectGameLibraryOOP
{
    public partial class MainWindow : Window
    {
        private List<GameInfo> gameList = new List<GameInfo>();

        public MainWindow()
        {
            InitializeComponent();
            LoadGameList();
        }

        private void LoadGameList()
        {
            string filePath = "games.json";
            if (File.Exists(filePath))
            {
                string jsonData = File.ReadAllText(filePath);
                gameList = JsonConvert.DeserializeObject<List<GameInfo>>(jsonData);
            }

            lvGameLib.ItemsSource = gameList;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // Maak een nieuwe Game object aan en vul de eigenschappen in met gegevens uit de textboxes
            GameInfo newGame = new GameInfo();
            newGame.Title = Gametxt.Text;
            newGame.Genre = Genretxt.Text;
            newGame.Publisher = Publishertxt.Text;
            newGame.Platform = Platformtxt.Text;
            newGame.ReleaseYear = int.Parse(Yeartxt.Text);

            // Voeg de nieuwe game toe aan de gameList
            gameList.Add(newGame);

            // Serializeer de gameList en sla het op als een JSON-bestand
            string json = JsonConvert.SerializeObject(gameList);
            File.WriteAllText("games.json", json);

            // Laad de gameList opnieuw in de ListView
            LoadGameList();
            lblStatus.Content = "Game added successfully!";
        }

        private void btnChange_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            // Laad alle spellen vanuit het JSON-bestand
            List<GameInfo> games = new List<GameInfo>();
            if (File.Exists("games.json"))
            {
                string json = File.ReadAllText("games.json");
                games = JsonConvert.DeserializeObject<List<GameInfo>>(json);
            }

            // Zoek het spel met de overeenkomstige titel, genre, uitgever of platform
            string searchTerm = Gametxt.Text;
            GameInfo searchResult = games.FirstOrDefault(g => g.Title == searchTerm || g.Genre == searchTerm || g.Publisher == searchTerm || g.Platform == searchTerm);

            // Toon de bijkomende details van het gevonden spel in de lijst
            lvGameLib.ItemsSource = null; // Maak de ItemsSource leeg
            lvGameLib.Items.Clear();
            if (searchResult != null)
            {
                lvGameLib.Items.Add($"Title: {searchResult.Title}");
                lvGameLib.Items.Add($"Genre: {searchResult.Genre}");
                lvGameLib.Items.Add($"Publisher: {searchResult.Publisher}");
                lvGameLib.Items.Add($"Platform: {searchResult.Platform}");
                lvGameLib.Items.Add($"Release Year: {searchResult.ReleaseYear}");
            }
            else
            {
                lvGameLib.Items.Add("No results found.");
            }
            RefreshListView();
        }

        // Roep deze functie aan wanneer je de ListView wil updaten met nieuwe gegevens
        private void RefreshListView()
        {
            LoadGameList();
        }
    }
}

