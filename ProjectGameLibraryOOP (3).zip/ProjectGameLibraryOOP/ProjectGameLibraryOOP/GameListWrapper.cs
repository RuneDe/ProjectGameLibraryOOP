﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectGameLibraryOOP
{
    internal class GameListWrapper:GameInfo
    {
        public GameInfo[] Games { get; set; }

        public GameListWrapper()
        {
            Games = new GameInfo[0];
        }
    }

}