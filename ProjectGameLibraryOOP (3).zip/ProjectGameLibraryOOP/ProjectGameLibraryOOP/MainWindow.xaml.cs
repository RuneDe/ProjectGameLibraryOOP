﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using Newtonsoft.Json;

namespace ProjectGameLibraryOOP
{
    public partial class MainWindow : Window
    {
        private List<GameInfo> gameList = new List<GameInfo>();

        public MainWindow()
        {
            InitializeComponent();
            LoadGameList();
        }
       


        private void LoadGameList()
        {
            try
            {
                string filePath = "games.json";
                if (File.Exists(filePath))
                {
                    string jsonData = File.ReadAllText(filePath);
                    gameList = JsonConvert.DeserializeObject<List<GameInfo>>(jsonData);
                }
                lstGames.ItemsSource = gameList;
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("The game list file could not be found. Please make sure that it exists and try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (IOException ex)
            {
                MessageBox.Show("An error occurred while reading the game list file. Please try again later.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private List<GameInfo> LoadGamesFromJsonFile()
        {
            List<GameInfo> games = new List<GameInfo>();
            try
            {
                using (StreamReader r = new StreamReader("games.json"))
                {
                    string json = r.ReadToEnd();
                    games = JsonConvert.DeserializeObject<List<GameInfo>>(json);
                }
            }
            catch (Exception ex)
            {
                lblStatus.Content = "Error loading games from file: " + ex.Message;
            }
            return games;
        }
        private void SaveGamesToJsonFile()
        {
            string json = JsonConvert.SerializeObject(gameList);
            File.WriteAllText("games.json", json);
        }

        private void ClearTextBox()
        {
            Gametxt.Text = "";
            Genretxt.Text = "";
            Publishertxt.Text = "";
            Platformtxt.Text="";
            Yeartxt.Text = "";
        }


        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Maak een nieuwe Game object aan en vul de eigenschappen in met gegevens uit de textboxes
                GameInfo newGame = new GameInfo();
                newGame.Title = Gametxt.Text;
                newGame.Genre = Genretxt.Text;
                newGame.Publisher = Publishertxt.Text;
                newGame.Platform = Platformtxt.Text;
                newGame.ReleaseYear = int.Parse(Yeartxt.Text);

                // Voeg de nieuwe game toe aan de gameList
                gameList.Add(newGame);

                // Serializeer de gameList en sla het op als een JSON-bestand
                string json = JsonConvert.SerializeObject(gameList);
                File.WriteAllText("games.json", json);

                // Laad de gameList opnieuw in de ListView
                LoadGameList();
                lblStatus.Content = "Game added successfully!";
                ClearTextBox();
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid year.");
            }
        }

        private void btnChange_Click(object sender, RoutedEventArgs e)
        {
            // Controleer of er een game is geselecteerd
            if (lstGames.SelectedItem != null)
            {
                // Haal de geselecteerde game op uit de list view
                GameInfo selectedGame = (GameInfo)lstGames.SelectedItem;

                // Maak een nieuwe game aan met de oude gegevens
                GameInfo updatedGame = new GameInfo()
                {
                    Title = selectedGame.Title,
                    Genre = selectedGame.Genre,
                    Publisher = selectedGame.Publisher,
                    Platform = selectedGame.Platform,
                    ReleaseYear = selectedGame.ReleaseYear
                };

                // Update de eigenschappen van de nieuwe game met de waarden uit de textboxes
                if (!string.IsNullOrWhiteSpace(Gametxt.Text))
                {
                    updatedGame.Title = Gametxt.Text;
                }
                if (!string.IsNullOrWhiteSpace(Genretxt.Text))
                {
                    updatedGame.Genre = Genretxt.Text;
                }
                if (!string.IsNullOrWhiteSpace(Publishertxt.Text))
                {
                    updatedGame.Publisher = Publishertxt.Text;
                }
                if (!string.IsNullOrWhiteSpace(Platformtxt.Text))
                {
                    updatedGame.Platform = Platformtxt.Text;
                }
                if (!string.IsNullOrWhiteSpace(Yeartxt.Text))
                {
                    updatedGame.ReleaseYear = int.Parse(Yeartxt.Text);
                }

                // Vervang de oude game met de bijgewerkte game in de lijst
                int index = gameList.IndexOf(selectedGame);
                gameList[index] = updatedGame;

                // Serializeer de gameList en sla het op als een JSON-bestand
                string json = JsonConvert.SerializeObject(gameList);
                File.WriteAllText("games.json", json);

                // Laad de gameList opnieuw in de ListView
                LoadGameList();
                lblStatus.Content = "Game updated successfully!";
                ClearTextBox();
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (lstGames.SelectedItem != null)
            {
                GameInfo selectedGame = (GameInfo)lstGames.SelectedItem;

                // set ItemsSource temporarily to null
                lstGames.ItemsSource = null;

                // remove game from list
                gameList.Remove(selectedGame);
                SaveGamesToJsonFile();

                // set ItemsSource back to gameList
                lstGames.ItemsSource = gameList;

                lblStatus.Content = "Game deleted successfully!";
                ClearTextBox();
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Clear the status label
                lblStatus.Content = "";

                // Get the search parameters from the text boxes
                string title = Gametxt.Text;
                string genre = Genretxt.Text;
                string publisher = Publishertxt.Text;
                string platform = Platformtxt.Text;
                int releaseYear;

                // Try to parse the release year text box value to an integer
                if (!int.TryParse(Yeartxt.Text, out releaseYear))
                {
                    // If the parsing fails, set the release year to 0
                    releaseYear = 0;
                }

                // Load the games from the JSON file
                List<GameInfo> games = LoadGamesFromJsonFile();

                // Create a list to hold the search results
                List<GameInfo> searchResults = new List<GameInfo>();

                // Loop through all the games and check if they match the search criteria
                foreach (GameInfo game in games)
                {
                    if (game.Title.ToLower().Contains(title.ToLower())
                        && game.Genre.ToLower().Contains(genre.ToLower())
                        && game.Publisher.ToLower().Contains(publisher.ToLower())
                        && game.Platform.ToLower().Contains(platform.ToLower())
                        && (releaseYear == 0 || game.ReleaseYear == releaseYear))
                    {
                        searchResults.Add(game);
                    }
                }

                // Display the search results in the list view
                lstGames.ItemsSource = searchResults;

                // Display a message if no search results were found
                if (searchResults.Count == 0)
                {
                    lblStatus.Content = "No games found.";
                }


            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("File not found: " + ex.Message);
            }
            catch (IOException ex)
            {
                MessageBox.Show("Error reading file: " + ex.Message);
            }
        }
    }
}

